create function test()
  returns TABLE(view timestamp without time zone, percentage double precision)
language plpgsql
as $$
DECLARE
  part float;
  total float;
  percentage float;
BEGIN
  Select  count(*)into part From log where log.status like '%404%' ;
  Select count(*) into total from log;
  percentage:= (part * 100) / total;
  if(percentage > 5) then
    RETURN query SELECT time as view ,percentage from log group by time order by percentage desc ;
  else
    RETURN  query Select time as view, 0 from log ;
  end if ;
END;
$$;

alter function test()
  owner to postgres;

