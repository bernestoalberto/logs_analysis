create function sum(adder integer)
  returns integer
language plpgsql
as $$
DECLARE
  part float;
  BEGIN
  part:= valor + adder;
  return part;
end;
$$;

alter function sum(integer)
  owner to postgres;

